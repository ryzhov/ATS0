/*
 * $Id: tcp_init.h 5902 2009-07-21 07:50:39Z bogdan_iancu $
 *
 * Copyright (C) 2001-2003 FhG Fokus
 *
 * This file is part of opensips, a free SIP server.
 *
 * opensips is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version
 *
 * opensips is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*!
 * \file
 * \brief TCP connection handling
 */

#ifndef tcp_init_h
#define tcp_init_h
#include "ip_addr.h"

int init_tcp();
void destroy_tcp();
int tcp_init(struct socket_info* sock_info);
int tcp_init_children(int *chd_rank);
void tcp_main_loop();
void tcp_receive_loop(int unix_sock);


#endif
