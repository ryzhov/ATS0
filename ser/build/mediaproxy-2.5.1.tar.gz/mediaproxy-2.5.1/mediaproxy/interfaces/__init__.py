# Copyright (C) 2008 AG-Projects.
#

"""Interfaces between Mediaproxy and the other components in the system"""

