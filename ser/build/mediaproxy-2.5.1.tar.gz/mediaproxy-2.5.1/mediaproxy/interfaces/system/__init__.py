# Copyright (C) 2008 AG-Projects.
#

"""Interfaces to interact with the underlying operating system"""

